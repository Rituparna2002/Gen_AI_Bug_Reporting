import os

from dotenv import load_dotenv

from google import genai



load_dotenv()



def generate_bug_report(prompt):

    api_key="AQ.Ab8RN6Jf6uelop1HGr97Hc308Vuav2WCm88itnfVHEtTNaaPPg"



    if not api_key:

        raise ValueError(

            "GEMINI_API_KEY is not configured."

        )

    client = genai.Client(

    api_key="AQ.Ab8RN6Jf6uelop1HGr97Hc308Vuav2WCm88itnfVHEtTNaaPPg"

   

)

    response = client.models.generate_content(

    model = "gemini-3.5-flash-lite",

    contents=prompt

    )



    return response.text