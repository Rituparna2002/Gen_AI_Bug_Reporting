from document_loader import load_documents
 
 
documents = load_documents(
    "knowledge_base"
)
 
for document in documents:
 
    print(
        "FILE:",
        document["filename"]
    )
 
    print(
        document["content"][:200]
    )
 
    print("--------------------")