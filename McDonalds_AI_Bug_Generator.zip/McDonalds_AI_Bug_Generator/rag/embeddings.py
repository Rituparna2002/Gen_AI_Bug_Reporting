import os
 
from dotenv import load_dotenv
from google import genai
 
load_dotenv()
 
 
def get_client():
 
    api_key = ( "AQ.Ab8RN6Jf6uelop1HGr97Hc308Vuav2WCm88itnfVHEtTNaaPPg"
    )
 
    if not api_key:
        raise ValueError(
            "GEMINI_API_KEY is not configured."
        )
 
    return genai.Client(
        api_key=api_key
    )
 
 
def create_embedding(text):
 
    client = get_client()
 
    response = client.models.embed_content(
        model="gemini-embedding-001",
        contents=text
    )
 
    return response.embeddings[0].values