import chromadb
 
from rag.embeddings import create_embedding
 
 
client = chromadb.PersistentClient(
    path="./chroma_db"
)
 
collection = client.get_or_create_collection(
    name="mcd_qa_knowledge"
)
 
 
def add_document(
    document_id,
    content,
    filename
):
 
    embedding = create_embedding(
        content
    )
 
    collection.upsert(
        ids=[document_id],
 
        documents=[content],
 
        embeddings=[embedding],
 
        metadatas=[
            {
                "source": filename
            }
        ]
    )
 
 
def search_documents(
    query,
    number_of_results=3
):
 
    query_embedding = create_embedding(
        query
    )
 
    results = collection.query(
        query_embeddings=[
            query_embedding
        ],
        n_results=number_of_results
    )
 
    return results