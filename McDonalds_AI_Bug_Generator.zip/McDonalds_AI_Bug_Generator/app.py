import streamlit as st
 
from prompts.bug_report_prompt import build_bug_report_prompt
from gemini_service import generate_bug_report
from retriever import retrieve_project_context
 
 
# ---------------------------------------------------------
# Page Configuration
# ---------------------------------------------------------
 
st.set_page_config(
    page_title="McD AI BugAssist",
    page_icon="🍔",
    layout="wide"
)
 
 
# ---------------------------------------------------------
# Application Title
# ---------------------------------------------------------
 
st.title("🍔 McD AI BugAssist")
 
st.subheader(
    "RAG-Powered GenAI Bug Report Generator"
)
 
st.write(
    "Generate project-aware professional bug reports "
    "using Gemini and McDonald's project knowledge."
)
 
 
# ---------------------------------------------------------
# Input Section
# ---------------------------------------------------------
 
st.header("Enter Bug Details")
 
 
bug_description = st.text_area(
    "Bug Description",
    placeholder=(
        "Example: Coupon is not applied after UPI payment."
    ),
    height=150
)
 
 
module = st.selectbox(
    "Module",
    [
        "Login",
        "Menu",
        "Search",
        "Cart",
        "Coupon",
        "Payment",
        "Checkout",
        "Order Tracking",
        "Other"
    ]
)
 
 
environment = st.text_input(
    "Environment",
    placeholder="Example: QA / UAT / Production"
)
 
 
col1, col2 = st.columns(2)
 
 
with col1:
 
    severity = st.selectbox(
        "Severity",
        [
            "Critical",
            "High",
            "Medium",
            "Low"
        ]
    )
 
 
with col2:
 
    priority = st.selectbox(
        "Priority",
        [
            "P1 - Critical",
            "P2 - High",
            "P3 - Medium",
            "P4 - Low"
        ]
    )
 
 
# ---------------------------------------------------------
# Generate Bug Report
# ---------------------------------------------------------
 
if st.button(
    "🚀 Generate Bug Report",
    type="primary"
):
 
    # Validate bug description
    if not bug_description.strip():
 
        st.warning(
            "Please enter a bug description."
        )
 
    else:
 
        try:
 
            # -------------------------------------------------
            # STEP 1: Retrieve Project Knowledge
            # -------------------------------------------------
 
            with st.spinner(
                "🔍 Searching project knowledge..."
            ):
 
                project_context = retrieve_project_context(
                    bug_description
                )
 
 
            # -------------------------------------------------
            # STEP 2: Build Project-Aware Prompt
            # -------------------------------------------------
 
            prompt = build_bug_report_prompt(
                bug_description,
                module,
                environment,
                severity,
                priority,
                project_context
            )
 
 
            # -------------------------------------------------
            # STEP 3: Send Prompt to Gemini
            # -------------------------------------------------
 
            with st.spinner(
                "🤖 Gemini is generating the bug report..."
            ):
 
                bug_report = generate_bug_report(
                    prompt
                )
 
 
            # -------------------------------------------------
            # STEP 4: Display Generated Bug Report
            # -------------------------------------------------
 
            st.success(
                "Bug report generated successfully!"
            )
 
            st.header(
                "📋 AI Generated Bug Report"
            )
 
            st.markdown(
                bug_report
            )
 
 
            # -------------------------------------------------
            # STEP 5: Display Retrieved Project Knowledge
            # -------------------------------------------------
 
            st.header(
                "🔎 Project Knowledge Retrieved"
            )
 
            with st.expander(
                "View Project Knowledge Used by AI"
            ):
 
                if project_context.strip():
 
                    st.write(
                        project_context
                    )
 
                else:
 
                    st.info(
                        "No relevant project knowledge was found."
                    )
 
 
        except Exception as e:
 
            st.error(
                "An error occurred while generating "
                "the bug report."
            )
 
            st.exception(e)