from rag.vector_store import search_documents
 
 
def retrieve_project_context(
    bug_description
):
 
    results = search_documents(
        bug_description,
        number_of_results=3
    )
 
    documents = results.get(
        "documents",
        [[]]
    )[0]
 
    metadatas = results.get(
        "metadatas",
        [[]]
    )[0]
 
    context_parts = []
 
    for document, metadata in zip(
        documents,
        metadatas
    ):
 
        source = metadata.get(
            "source",
            "Unknown"
        )
 
        context_parts.append(
            f"""
SOURCE: {source}
 
{document}
"""
        )
 
    return "\n".join(
        context_parts
    )