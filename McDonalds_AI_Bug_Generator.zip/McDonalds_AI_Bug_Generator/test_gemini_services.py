from gemini_service import generate_bug_report
 
 
prompt = """
Act as a Senior QA Engineer.
 
Generate a professional bug report for the following issue:
 
Bug:
Coupon is not applied after successful UPI payment.
 
Module:
Payment
 
Environment:
QA
 
Severity:
High
 
Priority:
High
 
Include:
1. Bug Summary
2. Preconditions
3. Steps to Reproduce
4. Expected Result
5. Actual Result
6. Suggested Root Cause
7. Regression Test Scenarios
 
Do not invent information.
Mark unavailable information as "Not provided"
or "Needs verification".
"""
 
result = generate_bug_report(prompt)
 
print(result)