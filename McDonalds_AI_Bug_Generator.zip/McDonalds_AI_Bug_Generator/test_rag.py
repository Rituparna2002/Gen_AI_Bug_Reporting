from rag.vector_store import search_documents
 
 
query = (
    "Coupon is not applied after UPI payment"
)
 
 
results = search_documents(
    query,
    number_of_results=3
)
 
 
print("Retrieved Documents:")
print("--------------------")
 
 
for document in results["documents"][0]:
 
    print(document)
    print("\n--------------------")