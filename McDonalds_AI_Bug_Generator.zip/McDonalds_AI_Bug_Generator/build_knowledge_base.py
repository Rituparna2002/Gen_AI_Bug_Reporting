from rag.document_loader import load_documents
from rag.vector_store import add_document
 
 
documents = load_documents(
    "knowledge_base"
)
 
 
for index, document in enumerate(
    documents
):
 
    document_id = (
        f"doc_{index}"
    )
 
    add_document(
        document_id=document_id,
        content=document["content"],
        filename=document["filename"]
    )
 
    print(
        f"Added: {document['filename']}"
    )
 
 
print(
    "Knowledge base created successfully!"
)