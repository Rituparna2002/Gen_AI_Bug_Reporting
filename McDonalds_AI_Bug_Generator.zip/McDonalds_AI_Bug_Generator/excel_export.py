import pandas as pd
from io import BytesIO
 
 
def create_excel_file(bug_report):
 
    data = {
        "Field": [
            "Bug Report"
        ],
        "Details": [
            bug_report
        ]
    }
 
    df = pd.DataFrame(data)
 
    output = BytesIO()
 
    with pd.ExcelWriter(
        output,
        engine="openpyxl"
    ) as writer:
 
        df.to_excel(
            writer,
            index=False,
            sheet_name="Bug Report"
        )
 
    output.seek(0)
 
    return output