from excel_export import create_excel_file
 
 
bug_report = """
Bug Summary:
Coupon is not applied after successful UPI payment.
 
Module:
Payment
 
Severity:
High
 
Priority:
High
 
Environment:
QA
 
Preconditions:
User has a valid coupon and items in the cart.
 
Steps to Reproduce:
1. Add an item to the cart.
2. Apply a valid coupon.
3. Proceed to payment.
4. Select UPI.
5. Complete the payment.
 
Expected Result:
Coupon discount should remain applied after payment.
 
Actual Result:
Coupon is removed after successful payment.
 
Suggested Root Cause:
Needs verification.
"""
 
excel_file = create_excel_file(bug_report)
 
with open("bug_report_test.xlsx", "wb") as file:
    file.write(excel_file.getvalue())
 
print("Excel file created successfully!")